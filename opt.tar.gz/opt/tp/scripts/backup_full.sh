#!/bin/bash

# Echo del mensaje que explica como se utiliza el script.
function echoUsage {
  echo "USAGE: $(basename $0) <Source directory> <Target directory>"
}

# Echo del mensaje que indica que es obligatorio el parámetro.
# Echo del mensaje que indica como se utiliza el script.
# Finaliza la ejecución con return code 1.
function argumentException {
  echo "ERROR: Argument missing: $1 directory is required."
  echoUsage
  exit 1
}

# Echo del mensaje que indica que es directorio el inválido.
# Echo del mensaje que indica como se utiliza el script.
# Finaliza la ejecución con return code 1.
function invalidException {
  echo "ERROR: Invalid directory $1."
  echoUsage
  exit 1
}

# Agrega una línea en el archivo recibido en $1, concatenando hora, minutos, segundos y el mensaje recibido en $2.
function log {
  TIME=$(date +'%H:%M:%S')
  echo "$TIME - $2" >> $1
}

SOURCE=$1
TARGET=$2

# Se validan los parámetros recibidos.
# Si existe un único parámetro y es "-h" se hace un echo del mensaje que explica el uso y se finaliza la ejecución con return code 0. En caso contrario se valida que los parámetros SOURCE y TARGET existan y sean directorios válidos.
if [ -z $SOURCE ]; then
  argumentException "Source"
elif [ $SOURCE = "-h" ] && [ -z $TARGET ];  then
  echoUsage
  exit 0
elif [ -z $TARGET ]; then
  argumentException "Target"
elif [ ! -d $SOURCE ]; then
  invalidException $1
elif [ ! -d $TARGET ]; then
  invalidException $2
fi

# Se formatea la variable SOURCE quitando la última barra "/" si existe y reemplazando "/" por "_" para usarla en los nombres de los archivos a generar.
# Se formatea la variable TARGET quitando la última barra "/" si existe para usarla en los path de los archivos a generar.
if [ $(echo $SOURCE | tail -c 2) = "/" ]; then
  SOURCE=$(echo $SOURCE | rev | cut -c 2- | rev)
fi
SOURCE=$(echo $SOURCE | cut -c 2- | sed 's/\//_/g')

if [ $(echo $TARGET | tail -c 2) = "/" ]; then
  TARGET=$(echo $TARGET | rev | cut -c 2- | rev)
fi

# Se crean variables con los nombres de los archivos.
NOW=$(date +'%Y%m%d')
TARGET_FILE="${TARGET}/${SOURCE}_bkp_${NOW}.tar.gz"
LOG_FILE="${TARGET}/${SOURCE}_bkp_${NOW}.log"

# Se crea el archivo de log si no existe.
touch $LOG_FILE
# Se vacía el archivo log que de esta ejecución.
cat /dev/null > $LOG_FILE

# Se loguea el estado del proceso.
log $LOG_FILE "Start backup process."

log $LOG_FILE "Target file: $TARGET_FILE."
log $LOG_FILE "Log file: $LOG_FILE."

log $LOG_FILE "Compressing files:"

# Se realiza el backup y se deja el output en el log.
tar cvzf $TARGET_FILE $1 >> $LOG_FILE

log $LOG_FILE "Finished process."

# No se implementa el aviso por mail porque Google prohibio el acceso mediante mutt desde el 30/05/2022
#https://support.google.com/accounts/answer/6010255#zippy=%2Csi-tu-cuenta-tiene-activado-el-acceso-de-aplicaciones-menos-seguras%2Csi-tu-cuenta-tiene-desactivado-el-acceso-de-aplicaciones-menos-seguras

exit 0
