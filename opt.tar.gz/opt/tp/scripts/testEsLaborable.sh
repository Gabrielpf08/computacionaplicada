#!/bin/bash

#Se solicita fecha y se guarda 
echo "Inserte una fecha en formato YYYY/MM/DD"
read fecha

./esLaborable.sh $fecha
