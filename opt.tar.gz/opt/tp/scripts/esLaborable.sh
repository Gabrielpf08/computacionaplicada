esLaborable() {

fecha=$1
#https://www.elmundoenbits.com/2013/04/date-format-bash-linux.html#.Y2PNe_3MKpo

#Asignamos numero de la semana de 1 a 7
diaaux1=$(date -d $fecha +'%u')

#Asignamos dia y mes para comparar contra nuestra "bdd"
diaaux2=$(date -d $fecha +'%d/%m')

#Comparamos
feriados=$(cat feriados.txt | grep -w $diaaux2)

#Revisamos que no sea fin de semana (sab dom)
if [ $diaaux1 = "6" ]; then

    echo "Sábados no son laborables"

elif [ $diaaux1 = "7" ]; then

     echo "Domingos no son laborables"

elif [ "$feriados" != -v ]; then

    echo "Es feriado no laborable."

# Si no es feriado ni fin de semana es laborable
else 
     echo "Es laborable, no te salvas"

fi

}

esLaborable $1
exit
