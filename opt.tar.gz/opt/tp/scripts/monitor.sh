#!/bin/bash

# Echo del mensaje que explica como se utiliza el script.
function echoUsage {
  echo "USAGE: $(basename $0) <Process name>"
}

# Echo del mensaje que indica que es obligatorio el parámetro.
# Echo del mensaje que indica como se utiliza el script.
# Finaliza la ejecución con return code 1.
function argumentException {
  echo "ERROR: Argument missing: $1 is required."
  echoUsage
  exit 1
}

# Se validan loa parámetros recibidos.
# Si el parámetro recibido es "-h" se hace un echo del mensaje que explica el del script y se finaliza la ejecución con return code 1. En caso contrario se valida que exista un parámetro.
if [ -z $1 ]; then
  argumentException "Process name"
elif [ $1 = "-h" ]; then
  echoUsage
  exit 0
fi

# Se valida si el proceso está en ejecución.
pidof $1 >/dev/null && echo "Process $1 is running." || echo "Process $1 is not running."

# No se implementa el aviso por mail porque Google prohibio el acceso mediante mutt desde el 30/05/2022
#https://support.google.com/accounts/answer/6010255#zippy=%2Csi-tu-cuenta-tiene-activado-el-acceso-de-aplicaciones-menos-seguras%2Csi-tu-cuenta-tiene-desactivado-el-acceso-de-aplicaciones-menos-seguras

exit 0
